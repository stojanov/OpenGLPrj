#pragma once

class Event
{
	
};