#include "OpenGLPrj.hpp"

#include <cstdio>
#include <cstdlib>
#include <functional>

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <array>

#include "StaticMesh.h"
#include "DynamicMesh.h"
#include "Shader.h"

static const auto PI = glm::pi<float>();
const int mWidth = 800;
const int mHeight = 800;

float lerp(float a, float b, float t)
{
    return (b - a) * t + a;
}

inline void CreateQuad(const std::unique_ptr<DynamicMesh>& mesh, glm::vec3& clr, std::array<glm::vec3, 4> points)
{
    mesh->AddVertex(points[0]);
    auto p0 = mesh->AddVertex(clr);
    mesh->AddVertex(points[1]);
    auto p1 = mesh->AddVertex(clr);
    mesh->AddVertex(points[2]);
    auto p2 = mesh->AddVertex(clr);
    mesh->AddVertex(points[3]);
    auto p3 = mesh->AddVertex(clr);

    mesh->ConnectVertices(p0, p1, p2);
    mesh->ConnectVertices(p2, p3, p0);
}

std::unique_ptr<StaticMesh> CreateHouse()
{
    static const glm::vec3 clr1{ 1.f, 0.f, 0.f };
    static const glm::vec3 clr2{ 0.f, 1.f, 0.f };

    static std::vector<float> vertices = {
        0.f, 0.25f, 0.f,        clr1.r, clr1.g, clr1.b,
        0.f, -0.25f, 0.f,       clr1.r, clr1.g, clr1.b,
        0.5f, -0.15f, 0.f,      clr1.r, clr1.g, clr1.b,
        0.5f, 0.35f, 0.f,       clr1.r, clr1.g, clr1.b,
        -0.35f, 0.25f, 0.f,     clr1.r, clr1.g, clr1.b,
        -0.35f, -0.25f, 0.f,    clr1.r, clr1.g, clr1.b,
        -0.15f, 0.45f, 0.f,     clr2.r, clr2.g, clr2.b,
        0.35f, 0.55f, 0.f,      clr2.r, clr2.g, clr2.b
    };

    static std::vector<uint32_t> indices = {
        0, 1, 2,
        2, 3, 0,
        4, 5, 1,
        1, 0, 4,
        0, 4, 6,
        0, 6, 7,
        7, 3, 0,
    };

    auto mesh = std::make_unique<StaticMesh>(Gl::BufferLayout({
        { Gl::ShaderDataType::Float3, "position" },
        { Gl::ShaderDataType::Float3, "color" }
    }));

    mesh->UploadVertexData(vertices);
    mesh->UploadIndexData(indices);

    return std::move(mesh);
}

std::unique_ptr<DynamicMesh> CreateCircle()
{
    auto mesh = std::make_unique<DynamicMesh>(Gl::BufferLayout({
        { Gl::ShaderDataType::Float3, "position" },
        { Gl::ShaderDataType::Float3, "color" }
    }));

    mesh->SetDrawType(GL_TRIANGLE_STRIP);

    std::vector<glm::vec3> colors{
        { 1.f, 0.f, 0.f },
        { 0.f, 1.f, 0.f },
        { 0.f, 0.f, 1.f },
        { 1.f, 0.f, 0.f },
    };

    const float radius = 0.5;
    const int samples = 100;

    float clrAcc = 0;
    const float clrStep = (1.f * colors.size() - 1) / samples;

    for (int i = 0; i < samples; i++)
    {
        const unsigned sClrIdx = glm::floor(clrAcc);
        const unsigned eClrIdx = glm::ceil(clrAcc);
        const float fracClr = clrAcc - sClrIdx;

        float angle = (1.f * i / (samples - 1)) * (PI * 2);

        glm::vec3 clr{
            lerp(colors[sClrIdx].r, colors[eClrIdx].r, fracClr),
            lerp(colors[sClrIdx].g, colors[eClrIdx].g, fracClr),
            lerp(colors[sClrIdx].b, colors[eClrIdx].b, fracClr),
        };

        mesh->AddVertex(glm::vec3{ 
            glm::cos(angle) * radius,
            glm::sin(angle) * radius,
            0.f
        });

        mesh->AddVertex(clr);
        mesh->AddVertex(glm::vec3{ 0.f, 0.f, 0.f });
        mesh->AddVertex(clr);

        clrAcc += clrStep;
    }

    mesh->FlushVertexData();

    return std::move(mesh);
}

std::unique_ptr<DynamicMesh> CreateLogo()
{
    glm::vec3 clr{ 1.f, 0.f, 0.f };

    auto mesh = std::make_unique<DynamicMesh>(Gl::BufferLayout({
        { Gl::ShaderDataType::Float3, "position" },
        { Gl::ShaderDataType::Float3, "color" }
    }));

    CreateQuad(mesh, clr, {
        glm::vec3{ 0.f, 1.f, 0.f },
        glm::vec3{ 0.25f, 0.5f, 0.f },
        glm::vec3{ 0.f, 0.f, 0.f },
        glm::vec3{ -0.25f, 0.5f, 0.f },
    });
    CreateQuad(mesh, clr, {
        glm::vec3{ 0.f, 0.f, 0.f },
        glm::vec3{ 0.5f, 0.0f, 0.f },
        glm::vec3{ 0.75f, -0.5f, 0.f },
        glm::vec3{ 0.25f, -0.5f, 0.f },
    });
    CreateQuad(mesh, clr, {
        glm::vec3{ 0.f, 0.f, 0.f },
        glm::vec3{ -0.5f, 0.0f, 0.f },
        glm::vec3{ -0.75f, -0.5f, 0.f },
        glm::vec3{ -0.25f, -0.5f, 0.f },
    });

    mesh->Flush();

    return std::move(mesh);
}

std::vector<std::unique_ptr<DynamicMesh>> CreateFlower()
{
    glm::vec3 clr{ .9f, 0.7f, 0.05f };
    glm::vec3 clr1{ .9f, 0.8f, 0.05f };

    std::vector<std::unique_ptr<DynamicMesh>> vec;
    vec.resize(2);

    auto mesh = std::make_unique<DynamicMesh>(Gl::BufferLayout({
        { Gl::ShaderDataType::Float3, "position" },
        { Gl::ShaderDataType::Float3, "color" }
    }));

    auto mesh2 = std::make_unique<DynamicMesh>(Gl::BufferLayout({
        { Gl::ShaderDataType::Float3, "position" },
        { Gl::ShaderDataType::Float3, "color" }
    }));

    mesh2->SetDrawType(GL_LINES);

    // Top
    CreateQuad(mesh, clr, {
        glm::vec3{ 0.f, 1.f, 0.f },
        glm::vec3{ 0.25f, 0.40f, 0.f },
        glm::vec3{ 0.0f, 0.0f, 0.f },
        glm::vec3{ -0.25f, 0.40f, 0.f },
	});
    // Bottom
    CreateQuad(mesh, clr, {
        glm::vec3{ 0.f, -1.f, 0.f },
        glm::vec3{ 0.25f, -0.40f, 0.f },
        glm::vec3{ 0.0f, 0.0f, 0.f },
        glm::vec3{ -0.25f, -0.40f, 0.f },
	});
    // Right
    CreateQuad(mesh, clr, {
        glm::vec3{ 0.f, 0.f, 0.f },
        glm::vec3{ 0.4f, 0.25f, 0.f },
        glm::vec3{ 1.f, 0.0f, 0.f },
        glm::vec3{ 0.4f, -0.25f, 0.f },
    });
    // Left
    CreateQuad(mesh, clr, {
        glm::vec3{ 0.f, 0.f, 0.f },
        glm::vec3{ -0.4f, 0.25f, 0.f },
        glm::vec3{ -1.f, 0.0f, 0.f },
        glm::vec3{ -0.4f, -0.25f, 0.f },
	});

    
    // Top Left
    CreateQuad(mesh2, clr1, {
        glm::vec3{-0.75f, 0.75f, 0.f },
        glm::vec3{ -0.25f, 0.40f, 0.f },
        glm::vec3{0.f, 0.f, 0.f },
        glm::vec3{ -0.4f, 0.25f, 0.f },
	});
    // Top Right
    CreateQuad(mesh2, clr1, {
        glm::vec3{0.75f, 0.75f, 0.f },
        glm::vec3{ 0.25f, 0.40f, 0.f },
        glm::vec3{0.f, 0.f, 0.f },
        glm::vec3{ 0.4f, 0.25f, 0.f },
	});
    // Bott Right
    CreateQuad(mesh2, clr1, {
        glm::vec3{0.75f, -0.75f, 0.f },
        glm::vec3{ 0.25f, -0.40f, 0.f },
        glm::vec3{0.f, 0.f, 0.f },
        glm::vec3{ 0.40f, -0.25f, 0.f },
	});
    // Bott Left
    CreateQuad(mesh2, clr1, {
	    glm::vec3{-0.75f, -0.75f, 0.f },
	    glm::vec3{ -0.25f, -0.40f, 0.f },
	    glm::vec3{0.f, 0.f, 0.f },
	    glm::vec3{ -0.40f, -0.25f, 0.f },
	});

    mesh->Flush();
    mesh2->Flush();

    vec[0] = std::move(mesh);
    vec[1] = std::move(mesh2);

    return vec;
}

std::vector<std::unique_ptr<DynamicMesh>> CreateRadioactive()
{
    glm::vec3 clr{ 0.f, 0.f, 0.f };

    static constexpr auto createPie = [](const glm::vec3& clr, int samples, float sAngle, float eAngle, float sRadius, float eRadius)
    {
        auto mesh = std::make_unique<DynamicMesh>(Gl::BufferLayout({
	        { Gl::ShaderDataType::Float3, "position" },
	        { Gl::ShaderDataType::Float3, "color" }
		}));

        mesh->SetDrawType(GL_TRIANGLE_STRIP);

        float angleRange = eAngle - sAngle;
        for (int i = 0; i < samples; i++)
        {
            float dA = ((1.f * i) / (samples - 1)) * angleRange + sAngle;

            float x = glm::cos(dA);
            float y = glm::sin(dA);

            mesh->AddVertex(glm::vec3{ x * sRadius, y * sRadius, 0.f });
            mesh->AddVertex(clr);
            mesh->AddVertex(glm::vec3{ x * eRadius, y * eRadius, 0.f });
            mesh->AddVertex(clr);
        }

        mesh->FlushVertexData();

        return std::move(mesh);
    };

    static constexpr int pieCount = 3;
    static constexpr float startRadius = 0.3f;
    static constexpr float endRadius = 0.8f;
    static constexpr int samples = 60;

    const float dA = (PI * 2) / (pieCount * 2);

    std::vector<std::unique_ptr<DynamicMesh>> vec;
    vec.resize(pieCount);

    float angle = 0;
    for (int i = 0; i < pieCount; i++)
    {
        vec[i] = createPie(clr, samples, angle, angle + dA, startRadius, endRadius);
        angle += dA * 2;
    }

    return vec;
}

int main(int argc, char * argv[]) {

    // Load GLFW and Create a Window
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    glfwWindowHint(GLFW_RESIZABLE, GL_FALSE);
    auto mWindow = glfwCreateWindow(mWidth, mHeight, "OpenGL", nullptr, nullptr);

    // Check for Valid Context
    if (mWindow == nullptr) { 
        fprintf(stderr, "Failed to Create OpenGL Context");
        return EXIT_FAILURE;
    }

    // Create Context and Load OpenGL Functions
    glfwMakeContextCurrent(mWindow);
    gladLoadGL();
    fprintf(stderr, "OpenGL %s\n", glGetString(GL_VERSION));

    auto house = CreateHouse();
    auto circle = CreateCircle();
    auto logo = CreateLogo();
    auto flower = CreateFlower();
    auto radioactive = CreateRadioactive();

    std::vector<std::function<void()>> funcs{
        [&house]() { house->DrawIndexed(); },
        [&circle]() { circle->DrawArrays(); },
        [&logo]() { logo->DrawIndexed(); },
        [&flower]()
        {
	        for (auto& p : flower)
	        {
                p->DrawIndexed();
	        }
        },
        [&radioactive]()
        {
            for (auto& p : radioactive)
            {
                p->DrawArrays();
            }
        },
    };

    auto shader = Gl::Shader::FromFiles("shaders/triangle.vert", "shaders/triangle.frag");

    int idx = 0;

    // Rendering Loop
    while (glfwWindowShouldClose(mWindow) == false) {
        if (glfwGetKey(mWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
            glfwSetWindowShouldClose(mWindow, true);

        if (glfwGetKey(mWindow, GLFW_KEY_0) == GLFW_PRESS)
            idx = 0;
        if (glfwGetKey(mWindow, GLFW_KEY_1) == GLFW_PRESS)
            idx = 1;
        if (glfwGetKey(mWindow, GLFW_KEY_2) == GLFW_PRESS)
            idx = 2;
        if (glfwGetKey(mWindow, GLFW_KEY_3) == GLFW_PRESS)
            idx = 3;
        if (glfwGetKey(mWindow, GLFW_KEY_4) == GLFW_PRESS)
            idx = 4;

        // Background Fill Color
        glClearColor(0.25f, 0.25f, 0.25f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        shader.Bind();

        funcs[idx]();

        // Flip Buffers and Draw
        glfwSwapBuffers(mWindow);
        glfwPollEvents();
    }

    glfwDestroyWindow(mWindow);
	glfwTerminate();
    return EXIT_SUCCESS;
}
